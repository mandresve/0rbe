#!/bin/sh
# Orbe — Developed by @mandresve
# 0RBE (formerly Orbe) - tool pak for NextUI (tg5040)
PAK_DIR="$(cd "$(dirname "$0")" && pwd)"

# Diagnostic log inside the pak itself (easy to find on the SD card).
LOG="$PAK_DIR/orbe-log.txt"
echo "== launch.sh started: $(date)" >"$LOG"
exec >>"$LOG" 2>&1

echo "0=$0 PAK_DIR=$PAK_DIR"
echo "DEVICE=$DEVICE PLATFORM=$PLATFORM"
echo "SDCARD_PATH=$SDCARD_PATH LOGS_PATH=$LOGS_PATH SHARED_USERDATA_PATH=$SHARED_USERDATA_PATH"
echo "uname: $(uname -a)"
echo "LD_LIBRARY_PATH(before)=$LD_LIBRARY_PATH"
echo "-- pak files:"
ls -la "$PAK_DIR"
echo "-- system SDL2:"
ls -la /usr/lib/libSDL2* /usr/trimui/lib/libSDL2* /lib/libSDL2* 2>&1
ls -la /lib/ld-linux-aarch64.so.1 2>&1

cd "$PAK_DIR" || { echo "ERROR: cannot cd into $PAK_DIR"; exit 1; }
export LD_LIBRARY_PATH="$PAK_DIR/lib:$LD_LIBRARY_PATH"

# Button debug mode: create an empty file named "debug-input" inside 0rbe.pak
[ -f "$PAK_DIR/debug-input" ] && export ORBE_DEBUG_INPUT=1
# Text drawn without the texture cache: create an empty file named "no-text-cache" inside 0rbe.pak
[ -f "$PAK_DIR/no-text-cache" ] && export ORBE_NO_TEXT_CACHE=1

chmod +x ./orbe 2>/dev/null
echo "-- running ./orbe"
./orbe
echo "== exit code $?"
sync
